import pybullet as p
import time
import pybullet_data
import numpy as np

# constant h : int
h=2
nb_cube=3
cubes_pos=[[1,1,h],[3,0,h],[100,0,h],[10,5,h]] #cube positions
cube_file=["0_0.urdf","1_0.urdf","2_0.urdf","3_0.urdf"]
physicsClient = p.connect(p.GUI)#or p.DIRECT for non-graphical version
p.setAdditionalSearchPath(pybullet_data.getDataPath()) #optionally
p.setGravity(0,0,0)
planeId = p.loadURDF("plane.urdf")

for i in range(nb_cube):
#for i in range(3,4):
	cubeStartPos = cubes_pos[i]
	x,y,z=np.random.randint(-1,2,1),np.random.randint(-1,2,1),np.random.randint(-1,2,1)
	cubeStartOrientation = p.getQuaternionFromEuler([x,y,z])
	cubId = p.loadURDF(cube_file[i],cubeStartPos, cubeStartOrientation,globalScaling=0.25)
	cubePos, cubeOrn = p.getBasePositionAndOrientation(cubId)
	print(cubePos,cubeOrn)

for i in range (10000):
	p.stepSimulation()
	time.sleep(1./240.)
p.disconnect()